<?php 
 
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'games');
	
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$stmt = $conn->prepare("SELECT Nama,Downloaded,Img,Description,ID,Link FROM listgamepc;");
	
	
	$stmt->execute();
	
	$stmt->bind_result($nama, $downloaded, $img, $description,$id,$link);
	
	$products = array(); 
	

	while($stmt->fetch()){
		$temp = array();
		$temp['nama'] = $nama; 
		$temp['downloaded'] = $downloaded; 
		$temp['Img'] = $img; 
		$temp['description']=$description;
		$temp['id']=$id;
		$temp['link']=$link;
		
		array_push($products, $temp);
	}
	
	echo json_encode($products);