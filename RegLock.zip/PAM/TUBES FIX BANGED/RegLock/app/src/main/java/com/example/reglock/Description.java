package com.example.reglock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.util.List;
import static com.example.reglock.ListViewAdapter.DESCRIPTION;
import static com.example.reglock.ListViewAdapter.DOWNLOADED;
import static com.example.reglock.ListViewAdapter.IMAGES;
import static com.example.reglock.ListViewAdapter.NAME;
import static com.example.reglock.ListViewAdapter.LINK;


public class Description extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);
        Intent intent = getIntent();
        String image = intent.getStringExtra(IMAGES);
        String nama = intent.getStringExtra(NAME);
        String downloaded = intent.getStringExtra(DOWNLOADED);
        String description = intent.getStringExtra(DESCRIPTION);
        final String link=intent.getStringExtra(LINK);

        ImageView imageView = findViewById(R.id.textView);
        TextView textViewName = findViewById(R.id.textViewTitle);
        TextView textViewDownload = findViewById(R.id.textViewDownloaded);
        TextView textViewDescription = findViewById(R.id.textViewdDescription);
        Button gotoBrowser = findViewById(R.id.gtwebsite);


        Picasso.with(this).load(image).fit().centerInside().into(imageView);
        textViewName.setText(nama);
        textViewDownload.setText(downloaded);
        textViewDescription.setText(description);
        gotoBrowser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse(link));
                startActivity(i);
            }
        });

    }
}
