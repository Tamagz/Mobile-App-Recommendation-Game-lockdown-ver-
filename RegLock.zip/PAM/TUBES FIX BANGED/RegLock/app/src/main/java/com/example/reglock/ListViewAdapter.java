package com.example.reglock;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ListViewAdapter extends ArrayAdapter<Games> {
    public static final String IMAGES = "Image";
    public static final String DOWNLOADED = "Download";
    public static final String NAME = "Name";
    public static final String DESCRIPTION="Description";
    public static final String LINK="Link";

    private List<Games> gamesList;


    private Context mCtx;


    public ListViewAdapter(List<Games> gamesList, Context mCtx) {
        super(mCtx, R.layout.list_items, gamesList);
        this.gamesList = gamesList;
        this.mCtx = mCtx;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(mCtx);


        View listViewItem = inflater.inflate(R.layout.list_items, null, true);


        TextView textViewName = listViewItem.findViewById(R.id.textViewTitle);
        TextView    textViewDownloaded=listViewItem.findViewById(R.id.textViewDownloaded);
        ImageView textViewImg=listViewItem.findViewById(R.id.textView);
        LinearLayout linearLayout=listViewItem.findViewById(R.id.change);



        Games games = gamesList.get(position);


        textViewName.setText(games.getName());
        textViewDownloaded.setText("Downloaded "+games.getDownloaded());
        Picasso.with(mCtx).load(games.getImg()).fit().centerInside().into(textViewImg);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mCtx,Description.class);
                Games ngambil=gamesList.get(position);
                intent.putExtra(IMAGES,ngambil.getImg());
                intent.putExtra(NAME,ngambil.getName());
                intent.putExtra(DOWNLOADED,ngambil.getDownloaded());
                intent.putExtra(DESCRIPTION,ngambil.getDescription());
                intent.putExtra(LINK,ngambil.getLink());
                mCtx.startActivity(intent);
            }
        });





        

        return listViewItem;
    }
}