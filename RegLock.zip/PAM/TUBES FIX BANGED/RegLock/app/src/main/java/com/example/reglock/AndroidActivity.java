package com.example.reglock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AndroidActivity extends AppCompatActivity {
    private static final String JSON_URL = "https://tamagz.github.io/JsonParse/db.json";


    ListView listView;


    List<Games> gamesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listView);
        gamesList = new ArrayList<>();


        loadGamesList();
    }

    private void loadGamesList() {

        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);


        progressBar.setVisibility(View.VISIBLE);


        StringRequest stringRequest = new StringRequest(Request.Method.GET, JSON_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressBar.setVisibility(View.INVISIBLE);


                        try {

                            JSONObject obj = new JSONObject(response);


                            JSONArray gamesArray = obj.getJSONArray("games");


                            for (int i = 0; i < gamesArray.length(); i++) {

                                JSONObject gamesObject = gamesArray.getJSONObject(i);


                                Games games = new Games(gamesObject.getString("Name"), gamesObject.getString("Downloaded"),gamesObject.getString("Img"),gamesObject.getString("Description"),gamesObject.getString("Link"));


                                gamesList.add(games);
                            }


                            ListViewAdapter adapter = new ListViewAdapter(gamesList, getApplicationContext());


                            listView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


        RequestQueue requestQueue = Volley.newRequestQueue(this);


        requestQueue.add(stringRequest);
    }
}

