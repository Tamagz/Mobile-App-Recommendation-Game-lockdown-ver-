package com.example.reglock;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MenuUtama extends AppCompatActivity {

    Button komputer;
    Button android;
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.awal);
        android=(Button)findViewById(R.id.Android);
        android.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaAndroid();
            }
        });
        komputer=(Button)findViewById(R.id.Komputer);
        komputer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaKomputer();
            }
        });

}
 public void bukaKomputer(){
        Intent buka2=new Intent("com.example.reglock.KomputerActivity");
        startActivity(buka2);
 }
public void bukaAndroid(){
    Intent buka=new Intent(this, AndroidActivity.class);
    startActivity(buka);
}

}
