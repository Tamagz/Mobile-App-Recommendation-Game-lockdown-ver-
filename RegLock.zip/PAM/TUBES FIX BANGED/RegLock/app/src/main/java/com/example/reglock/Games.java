package com.example.reglock;

public class Games {
    String name,downloaded,img,description,link;

    public Games(String name, String downloaded, String img,String description,String link) {
        this.name = name;
        this.downloaded=downloaded;
        this.img=img;
        this.description=description;
        this.link=link;



    }
public String getLink(){
        return link;
}


    public String getDescription() {
        return description;
    }

    public String getImg(){
        return img;
    }

    public String getDownloaded() {
        return downloaded;
    }

    public String getName() {
        return name;
    }


}